namespace OrbitLauncher.Utilities;

internal static partial class AppConfiguration
{
    static partial void ApplyLocal(Values values)
    {
        values.MicrosoftClientId = "0df6579a-f033-4283-97ae-83b4ff0d6cee";
        values.CurseForgeApiKey = "$2a$10$s8zQjZNCnwhNzSVe3nsl0uwpAya25SmDl9qSV6.qNtizffbgnYE2W";
    }
}
